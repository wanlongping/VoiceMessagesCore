package com.voicemessage.myapplication.presenter;

import android.content.Context;

import com.voicemessage.myapplication.model.IRecordingModel;
import com.voicemessage.myapplication.model.RecordingModelImpl;
import com.voicemessage.myapplication.view.IRecordingActivityView;

/**
 * MVP 的Presenter接口实现类
 *
 * @author wlp 2018年11月10日 创建<br>
 */
public class RecordingPresenterImpl implements IRecordingPresenter{
    private IRecordingActivityView mView;
    private IRecordingModel mModel;

    public RecordingPresenterImpl(Context context, IRecordingActivityView view) {
        mView = view;
        mModel = new RecordingModelImpl(context, this);
    }

    @Override
    public void addData(float seconds, String filePath) {
        mModel.addData(seconds, filePath);
    }

    @Override
    public void addDataFinish() {
        mView.addDataFinish();
    }
}
