package com.voicemessage.myapplication.view;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaPlayer;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.voicemessage.myapplication.R;
import com.voicemessage.myapplication.bean.Record;
import com.voicemessage.myapplication.manager.MediaManager;
import com.voicemessage.myapplication.utils.CommonsUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import static com.voicemessage.myapplication.utils.FileUtils.deleteFile;

/**
 * 录音留言中心
 *
 * @author wlp 2018年10月21日 创建<br>
 */
public class RecordingMessagesAdapter extends BaseAdapter {
    private PopupWindow mPopWindow;
    private Context mContext;
    private AudioRecordButton mEmTvBtn;
    //标记当前录音索引，默认没有播放任何一个
    private int pos = -1;
    //留言数据列表
    public static List<Record> mRecords;
    static List<AnimationDrawable> mAnimationDrawables;

    public RecordingMessagesAdapter(Context context, List<Record> records, AudioRecordButton mEmTvBtn) {
        this.mEmTvBtn = mEmTvBtn;
        this.mContext = context;
        this.mRecords = records;
        mAnimationDrawables = new ArrayList<AnimationDrawable>();
    }

    @Override
    public int getCount() {
        return mRecords.size();
    }

    @Override
    public Object getItem(int position) {
        return mRecords.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ViewHolder viewHolder;
        if (convertView == null) {
            convertView = LayoutInflater.from(mContext).inflate(R.layout.item_recording, null);
            viewHolder = new ViewHolder();
            viewHolder.ieaTvRecordTime = (TextView) convertView.findViewById(R.id.iea_tv_recordTime);
            viewHolder.ieaIvVoiceLine = (ImageView) convertView.findViewById(R.id.iea_iv_voiceLine);
            viewHolder.ieaLlSinger = (LinearLayout) convertView.findViewById(R.id.iea_ll_singer);
            viewHolder.ieaTvVoicetime1 = (TextView) convertView.findViewById(R.id.iea_tv_voicetime1);
            viewHolder.ieaIvRed = (ImageView) convertView.findViewById(R.id.iea_iv_red);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        final Record record = mRecords.get(position);

        //控制显示每隔10分种显示录音时间
        if (record.isShowTime()) {
            viewHolder.ieaTvRecordTime.setVisibility(View.VISIBLE);
            SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            String time = sf.format(Long.valueOf(record.getRecordTime()));
            if (isToday(time)) {
                time = mContext.getString(R.string.today) + " " + time.split(" ")[1];
            } else if (isYesterday(time)) {
                time = mContext.getString(R.string.yesterday) + " " + time.split(" ")[1];
            }
            viewHolder.ieaTvRecordTime.setText(time);
        }else {
            viewHolder.ieaTvRecordTime.setVisibility(View.GONE);
        }

        //设置显示时长
        viewHolder.ieaTvVoicetime1.setText(record.getSecond() <= 0 ? 1 + "''" : record.getSecond() + "''");
        if (!record.isPlayed()) {
            viewHolder.ieaIvRed.setVisibility(View.VISIBLE);
        } else {
            viewHolder.ieaIvRed.setVisibility(View.GONE);
        }

        //更改并显示录音条长度
        RelativeLayout.LayoutParams ps = (RelativeLayout.LayoutParams) viewHolder.ieaIvVoiceLine.getLayoutParams();
        ps.width = CommonsUtils.getVoiceLineWight(mContext, record.getSecond());
        //更改语音长条长度
        viewHolder.ieaIvVoiceLine.setLayoutParams(ps);
        //开始设置监听
        final LinearLayout ieaLlSinger = viewHolder.ieaLlSinger;
        final AnimationDrawable animationDrawable = (AnimationDrawable) ieaLlSinger.getBackground();

        viewHolder.ieaIvVoiceLine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //如果按钮按下正在进行录音，则无法点击气泡进行留言播放
                if(mEmTvBtn.isRecording) {
                    return;
                }
                //只要点击就设置为已播放状态（隐藏小红点）
                record.setPlayed(true);
                viewHolder.ieaIvRed.setVisibility(View.GONE);
                //这里更新数据库小红点。这里不知道为什么可以强转建议复习复习基础~
                ((RecordingMessagesActivity) mContext).getmRecordingDao().updateRecord(record);
                //重置动画
                if (!mAnimationDrawables.contains(animationDrawable)) {
                    mAnimationDrawables.add(animationDrawable);
                }
                resetAnim();
                animationDrawable.start();
                //处理点击正在播放的语音时，可以停止；再次点击时重新播放。
                if (pos == position) {
                    if (record.isPlaying()) {
                        record.setPlaying(false);
                        MediaManager.release();
                        animationDrawable.stop();
                        animationDrawable.selectDrawable(0);//reset
                        return;
                    } else {
                        record.setPlaying(true);
                    }
                }
                //记录当前位置正在播放。
                pos = position;
                record.setPlaying(true);
                //播放前重置。
                MediaManager.release();
                //开始实质播放
                MediaManager.playSound(record.getPath(),
                        new MediaPlayer.OnCompletionListener() {
                            @Override
                            public void onCompletion(MediaPlayer mp) {
                                animationDrawable.selectDrawable(0);//显示动画第一帧
                                animationDrawable.stop();
                                //播放完毕，当前播放索引置为-1。
                                pos = -1;
                            }
                        });
            }
        });

        //设置长按监听，标为未读/已读和删除
        viewHolder.ieaIvVoiceLine.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                showPopupWindow(v, record);
                return true;
            }
        });
        return convertView;
    }
    //自定义popupWindow
    private void showPopupWindow(View v, final Record record){
        View contentView = LayoutInflater.from(mContext).inflate(R.layout.popupwindow_recording,null);
        mPopWindow = new PopupWindow(contentView);
//        mPopWindow.setWidth(ViewGroup.LayoutParams.WRAP_CONTENT);
//        mPopWindow.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
        mPopWindow.setWidth(350);
        mPopWindow.setHeight(150);
        TextView signReadedOrNot = (TextView) contentView.findViewById(R.id.sign_readed_or_not);
        TextView deleteRecordFile = (TextView) contentView.findViewById(R.id.delete_record_file);
        if (!record.isPlayed()) {
            //语音未播放，标为已读
            signReadedOrNot.setText(R.string.record_marked_as_readed);
            //将未读留言标为已读，红点消失
            signReadedOrNot.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    dismissPopupWindow();
                    record.setPlayed(true);
                    notifyDataSetChanged();
                    //这里更新数据库小红点。这里不知道为什么可以强转建议复习复习基础~
                    ((RecordingMessagesActivity) mContext).getmRecordingDao().updateRecord(record);
                    //刷新页面
                    ((RecordingMessagesActivity) mContext).initAdapter();
                }
            });
        } else {
            //语音已播放,标为未读
            signReadedOrNot.setText(R.string.record_marked_as_unread);
            //将已读留言标为未读，显示红点
            signReadedOrNot.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    dismissPopupWindow();
                    record.setPlayed(false);
                    notifyDataSetChanged();
                    //这里更新数据库小红点。这里不知道为什么可以强转建议复习复习基础~
                    ((RecordingMessagesActivity) mContext).getmRecordingDao().updateRecord(record);
                    //刷新页面
                    ((RecordingMessagesActivity) mContext).initAdapter();
                }
            });
        }
        deleteRecordFile.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                dismissPopupWindow();

                //自定义AlertDialog对话框
                AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                LayoutInflater inflater = LayoutInflater.from(mContext);
                View v1 = inflater.inflate(R.layout.alertdialog_recording, null);
                TextView no = (TextView) v1.findViewById(R.id.no);
                TextView yes = (TextView) v1.findViewById(R.id.yes);
                final Dialog dialog = builder.create();
                dialog.show();
                dialog.getWindow().setContentView(v1);

                //通过代码设置AlertDialog对话框的宽和高
                android.view.WindowManager.LayoutParams p = dialog.getWindow().getAttributes(); //获取对话框当前的参数值
                p.height = 500;
                p.width = 900;
                dialog.getWindow().setAttributes(p);

                //设置AlertDialog对话框在屏幕的中央显示
                dialog.getWindow().setGravity(Gravity.CENTER);
                //“取消”
                no.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
                //“确定”
                yes.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                        //停止掉当前正在播放的留言
                        MediaManager.release();
                        //获取单条音频文件的路径
                        String filePath = record.getPath();
                        //彻底删除单条音频文件，防止系统内存不足
                        deleteFile(filePath);
                        //删除留言
                        ((RecordingMessagesActivity) mContext).getmRecordingDao().deleteRecord(record);
                        //刷新页面
                        ((RecordingMessagesActivity) mContext).initAdapter();
                    }
                });
            }
        });
        //设置点击popupwindow区域以外的地方可以隐藏popupwindow
        mPopWindow.setBackgroundDrawable(new BitmapDrawable());
        mPopWindow.setFocusable(true);
        mPopWindow.setOutsideTouchable(true);
        mPopWindow.update();
        //设置气泡显示的位置
        mPopWindow.showAsDropDown(v, 0, -300);

    }

    /**
     * 设置点击popupwindow区域以外的地方可以隐藏popupwindow
     */
    private void dismissPopupWindow(){
        mPopWindow.dismiss();
    }

    public static void resetAnim() {
        for (AnimationDrawable ad : mAnimationDrawables) {
            ad.selectDrawable(0);
            ad.stop();
        }
    }

    class ViewHolder {
        TextView ieaTvRecordTime;
        ImageView ieaIvVoiceLine;
        LinearLayout ieaLlSinger;
        TextView ieaTvVoicetime1;
        ImageView ieaIvRed;
    }

    /**
     * 是否今天
     * @param time
     * @return
     */
    private boolean isToday(String time) {
        if (0 == dayCount(time)) {
            return true;
        }
        return false;
    }

    /**
     * 是否昨天
     * @param time
     * @return
     */
    private boolean isYesterday(String time) {
        if (1 == dayCount(time)) {
            return true;
        }
        return false;
    }

    /**
     * 计算时间差
     * @param time
     * @return
     */
    private int dayCount(String time) {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        String today = sf.format(calendar.getTime());
        long now = Long.valueOf(today.split(" ")[0]
                .replaceAll("-", ""));
        long t = Long.valueOf(time.split(" ")[0]
                .replaceAll("-", ""));
        return (int) (now - t);
    }
}
