package com.voicemessage.myapplication.common;

/**
 * 常量
 *
 * @author: wlp 2018年10月13 创建<br>
 */
public class Constant {

    /**
     * 文件路径管理类
     */
    public static class FilePath {
        public static final String ROOT_PATH = "wxr/";
        public static final String RECORD_DIR = "record/";
    }

    // 参数文件名
    public static final String PREFS_NAME = "Prefs";

}
