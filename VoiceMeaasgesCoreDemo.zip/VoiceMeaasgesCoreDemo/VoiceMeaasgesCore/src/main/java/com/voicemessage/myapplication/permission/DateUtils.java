package com.voicemessage.myapplication.permission;

import android.content.Context;

import com.voicemessage.myapplication.R;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * 日期类
 *
 * @author wlp 2018年9月26日 创建<br>
 */
public class DateUtils {
    public final static String FORMAT_YMDHMS = "yyyy-MM-dd HH:mm:ss";
    public final static String FORMAT_YMDHMS_2 = "yyyy.MM.dd HH:mm:ss";
    public final static String FORMAT_DMYHMS = "dd-MM-yyyy HH:mm:ss";
    public final static String FORMAT_YMDHM = "yyyy-MM-dd HH:mm";
    public final static String FORMAT_YMD = "yyyy-MM-dd";
    public final static String FORMAT_MD = "MM-dd";
    public final static String FORMAT_HMS = "HH:mm:ss";
    public final static String FORMAT_HM = "HH:mm";
    public final static String FORMAT_YMDHMS_WALLET = "yyyy/MM/dd HH:mm:ss";
    // private static TimeZone mTimeZone = TimeZone.getTimeZone("GMT+08:00");

    /**
     * 日期型转换为字符串
     */
    public static String dateToStr(final Date date, final String format) {
        SimpleDateFormat sf = new SimpleDateFormat(format, Locale.getDefault());
        return sf.format(date);
    }

    /**
     * 日期型转换为字符串
     *
     * @throws ParseException
     */
    public static Date strToDate(final String date, final String format) throws ParseException {
        SimpleDateFormat sf = new SimpleDateFormat(format, Locale.getDefault());
        return sf.parse(date);
    }

    /**
     * 获取当前时间
     */
    public static String getNow(final String format) {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sf = new SimpleDateFormat(format, Locale.getDefault());
        return sf.format(calendar.getTime());
    }

    /**
     * 获取当前时间
     */
    public static String getNow() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sf = new SimpleDateFormat(FORMAT_YMDHMS, Locale.getDefault());
        return sf.format(calendar.getTime());
    }

    /**
     * 获取当前时间
     */
    public static long getNowMillTime() {
        Calendar calendar = Calendar.getInstance();
        return calendar.getTimeInMillis();
    }

    /**
     * 获取当前时间小时
     */
    public static String getNowHours() {
        Calendar calendar = Calendar.getInstance();
        return String.format(Locale.getDefault(), "%02d", calendar.get(Calendar.HOUR_OF_DAY));
    }

    /**
     * 获取当前时间分钟
     */
    public static String getNowMinutes() {
        Calendar calendar = Calendar.getInstance();
        return String.format(Locale.getDefault(), "%02d", calendar.get(Calendar.MINUTE));
    }

    /**
     * 获取当前时间(eg.(HH:mm))
     */
    public static String getNowHoursMinutes() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sf = new SimpleDateFormat("HH:mm");
        return sf.format(calendar.getTime());
    }

    /**
     * 获取当前时间(eg.(HH:mm))
     */
    public static String getHoursMinutes(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        SimpleDateFormat sf = new SimpleDateFormat("HH:mm");
        return sf.format(calendar.getTime());
    }

    /**
     * 获取当前年月
     */
    public static String getYM() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sf = new SimpleDateFormat("yyyyMM", Locale.getDefault());
        return sf.format(calendar.getTime());
    }

    /**
     * 获取当前年
     */
    public static String getYear() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sf = new SimpleDateFormat("yyyy", Locale.getDefault());
        return sf.format(calendar.getTime());
    }

    /**
     * 获取当前周
     */
    public static String getSceneWeekDay() {
        String weekDay = "";
        Calendar calendar = Calendar.getInstance();
        switch (calendar.get(Calendar.DAY_OF_WEEK)) {
            case 1:
                weekDay += "sun";
                break;
            case 2:
                weekDay += "mon";
                break;
            case 3:
                weekDay += "tue";
                break;
            case 4:
                weekDay += "wed";
                break;
            case 5:
                weekDay += "thu";
                break;
            case 6:
                weekDay += "fri";
                break;
            case 7:
                weekDay += "sat";
                break;
        }
        return weekDay;
    }


    /**
     * 获取当前日期的星期
     *
     * @return 星期几
     */
    public static char getWeekOfData() {
        char[] weekDays = {'7', '1', '2', '3', '4', '5', '6'};
        Calendar calendar = Calendar.getInstance();
        int w = calendar.get(Calendar.DAY_OF_WEEK) - 1;
        if (w < 0) {
            w = 0;
        }
        return weekDays[w];
    }

    /**
     * 获取当前日期'yyyyMMdd'
     */
    public static String getYMD() {
        return getNow("yyyyMMdd");
    }

    /**
     * 获取当前年加减
     * <p>
     * 入参格式: yyyy
     */
    public static String getYearAdd(final String year, final int offset) {
        if (year == null || year.length() != 4) {
            return year;
        }
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, Integer.valueOf(year));
        calendar.add(Calendar.YEAR, offset);
        SimpleDateFormat sf = new SimpleDateFormat("yyyy", Locale.getDefault());
        return sf.format(calendar.getTime());
    }

    /**
     * 获取当前年加减
     */
    public static String getYearAdd(final int offset) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.YEAR, offset);
        SimpleDateFormat sf = new SimpleDateFormat("yyyy", Locale.getDefault());
        return sf.format(calendar.getTime());
    }

    /**
     * 获取当前月加减
     * <p>
     * 入参格式:yyyyMM
     */
    public static String getMonthAdd(final String ym, final int offset) throws ParseException {
        if (ym == null || ym.length() != 6) {
            return ym;
        }
        Calendar calendar = Calendar.getInstance();
        Date date = strToDate(ym, "yyyyMM");
        calendar.setTime(date);
        calendar.add(Calendar.MONTH, offset);
        SimpleDateFormat sf = new SimpleDateFormat("yyyyMM", Locale.getDefault());
        return sf.format(calendar.getTime());
    }

    /**
     * 获取当前月加减
     */
    public static String getMonthAdd(final int offset) throws ParseException {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, offset);
        SimpleDateFormat sf = new SimpleDateFormat("yyyyMM", Locale.getDefault());
        return sf.format(calendar.getTime());
    }

    /**
     * 获取当前日加减
     * <p>
     * 入参格式:yyyyMMdd
     */
    public static String getDayAdd(final String ymd, final int offset) throws ParseException {
        if (ymd == null || ymd.length() != 8) {
            return ymd;
        }
        Calendar calendar = Calendar.getInstance();
        Date date = strToDate(ymd, "yyyyMM");
        calendar.setTime(date);
        calendar.add(Calendar.DATE, offset);
        SimpleDateFormat sf = new SimpleDateFormat("yyyyMMdd", Locale.getDefault());
        return sf.format(calendar.getTime());
    }

    /**
     * 获取当前日加减
     */
    public static String getDayAdd(final int offset) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, offset);
        SimpleDateFormat sf = new SimpleDateFormat("yyyyMMdd", Locale.getDefault());
        return sf.format(calendar.getTime());
    }

    /**
     * 获取日期
     */
    public static String getDate(final long milliseconds, final String pattern) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(milliseconds);
        SimpleDateFormat sf = new SimpleDateFormat(pattern, Locale.getDefault());
        return sf.format(calendar.getTime());
    }

    /**
     * 获取日期 FORMAT_YMDHMS
     */
    public static String getDate(final long milliseconds) {
        return getDate(milliseconds, FORMAT_YMDHMS);
    }

    /**
     * 获取日期 FORMAT_YMDHM
     */
    public static String getDateMinute(final long milliseconds) {
        return getDate(milliseconds, FORMAT_YMDHM);
    }

    /**
     * 获取日期 FORMAT_YMD
     */
    public static String getDateDay(long milliseconds) {
        return getDate(milliseconds, FORMAT_YMD);
    }

    /**
     * 获取日期 FORMAT_YMD
     */
    public static String getDateDay(Date date) {
        return new SimpleDateFormat(FORMAT_YMD, Locale.getDefault()).format(date);
    }

    /**
     * 将秒数转换成"时:分:秒"(e.g."01:01:30")
     */
    public static String getTime(long sec) {
        int ss = 1;
        int mi = ss * 60;
        int hh = mi * 60;
        long hour = (sec) / hh;
        long minute = (sec % hh) / mi;
        long second = (sec % mi) / ss;
        if (hour > 0) {
            return String.format(Locale.getDefault(), "%02d:%02d:%02d", hour, minute, second);
        } else {
            return String.format(Locale.getDefault(), "00:%02d:%02d", minute, second);
        }
    }

    /**
     * 开始时间是否大于或等于结束时间
     *
     * @return true:是 false: 否
     */
    public static boolean compareTime(final String startTime, final String endTime) {
        SimpleDateFormat formatter = null;
        if (startTime.length() > 5) {
            formatter = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        } else {
            formatter = new SimpleDateFormat("HH:mm", Locale.getDefault());
        }
        Date start = new Date();
        Date end = new Date();
        try {
            start = formatter.parse(startTime);
            end = formatter.parse(endTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        if (start.compareTo(end) >= 0) {
            return true;
        }
        return false;
    }

    /**
     * 开始日期是否大于或等于结束日期
     *
     * @return true:是 false: 否
     */
    public static boolean compareDate(final String startdate, final String enddate) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        Date start = new Date();
        Date end = new Date();
        try {
            start = formatter.parse(startdate);
            end = formatter.parse(enddate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        if (start.compareTo(end) >= 0) {
            return true;
        }
        return false;
    }

    /**
     * 获取字符串时间转成毫秒数
     *
     * @param timeStr
     */
    public static long getMillTime(final String timeStr) {
        long milltime = 0;
        SimpleDateFormat formatter = new SimpleDateFormat(FORMAT_YMDHMS, Locale.getDefault());
        try {
            milltime = formatter.parse(timeStr).getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return milltime;
    }

    /**
     * 获取字符串时间转成毫秒数
     *
     * @param timeStr
     */
    public static long getMillTime(final String timeStr, String format) {
        long milltime = 0;
        SimpleDateFormat formatter = new SimpleDateFormat(format, Locale.getDefault());
        try {
            milltime = formatter.parse(timeStr).getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return milltime;
    }

    /**
     * 当前时间在范围内返回true 否则返回false
     *
     * @param fromTime
     * @param toTime
     * @return
     */
    public static boolean compareToNow(final String fromTime, final String toTime) {
        SimpleDateFormat sdf = new SimpleDateFormat(FORMAT_YMDHMS, Locale.getDefault());
        long start = 0;
        long end = 0;
        long now = getNowMillTime();
        try {
            start = sdf.parse(fromTime).getTime();
            end = sdf.parse(toTime).getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return now >= start && now <= end;
    }

    /**
     * 判断当前时间是否在权限的有效时间内
     *
     * @param effectTime 权限生效时间
     * @param expireTime 权限失效时间
     * @return
     */
    public static boolean validToNow(long effectTime, long expireTime) {
        long now = System.currentTimeMillis();
        if (effectTime == 0 || expireTime == 0) {
            return true;
        }
        return now >= effectTime && now <= expireTime;
    }

    /**
     * 是否是今天
     *
     * @param date
     * @return
     */
    public static boolean isToday(final String date, final String format) {
        try {
            Date mDate = strToDate(date, format);
            return isTheDay(mDate, Calendar.getInstance().getTime());
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 是否是今天
     *
     * @param date
     * @return
     */
    public static boolean isToday(final String date) {
        try {
            Date mDate = strToDate(date, FORMAT_YMDHMS);
            return isTheDay(mDate, Calendar.getInstance().getTime());
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 是否是今天
     *
     * @param date
     * @return
     */
    public static boolean isToday(final Date date) {
        return isTheDay(date, Calendar.getInstance().getTime());
    }

    /**
     * 是否是今天
     *
     * @param date
     * @return
     */
    public static boolean isYesterday(final Date date) {
        return isTheDay(date, new Date(System.currentTimeMillis() - 86400000));
    }

    /**
     * 是否是指定日期
     *
     * @param date
     * @param day
     * @return
     */
    public static boolean isTheDay(final Date date, final Date day) {
        return date.getTime() >= DateUtils.dayBegin(day).getTime() && date.getTime() <= DateUtils.dayEnd(day).getTime();
    }

    /**
     * 获取指定时间的那天 00:00:00.000 的时间
     *
     * @param date
     * @return
     */
    public static Date dayBegin(final Date date) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTime();
    }

    /**
     * 获取指定时间的那天 23:59:59.999 的时间
     *
     * @param dateTime
     * @return
     */
    public static long dayBegin(final long dateTime) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(dateTime);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    /**
     * 获取指定时间的那天 23:59:59.999 的时间
     *
     * @param date
     * @return
     */
    public static Date dayEnd(final Date date) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.set(Calendar.HOUR_OF_DAY, 23);
        c.set(Calendar.MINUTE, 59);
        c.set(Calendar.SECOND, 59);
        c.set(Calendar.MILLISECOND, 999);
        return c.getTime();
    }

    /**
     * 获取指定时间的那天 23:59:59.999 的时间
     *
     * @param dateTime
     * @return
     */
    public static long dayEnd(final long dateTime) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(dateTime);
        c.set(Calendar.HOUR_OF_DAY, 23);
        c.set(Calendar.MINUTE, 59);
        c.set(Calendar.SECOND, 59);
        c.set(Calendar.MILLISECOND, 999);
        return c.getTimeInMillis();
    }

    public static String converLongTimeToStr(long millisecond) {
        int ss = 1000;
        int mi = ss * 60;
        int hh = mi * 60;

        long hour = (millisecond) / hh;
        long minute = (millisecond % hh) / mi;
        long second = (millisecond % mi) / ss;

        if (hour > 0) {
            return String.format(Locale.getDefault(), "%02d:%02d:%02d", hour, minute, second);
        } else {
            return String.format(Locale.getDefault(), "%02d:%02d", minute, second);
        }
    }

    /**
     * 时间long 转换为6字节数组
     *
     * @param time 格式 2016-03-02 16：55：00
     * @return
     */
    public static byte[] timeToByteArray6(long time) {
        SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        String timeStr = sf.format(time);
        byte[] dateTime = new byte[6];
        dateTime[0] = Byte.valueOf(timeStr.substring(0, 2));
        dateTime[1] = Byte.valueOf(timeStr.substring(2, 4));
        dateTime[2] = Byte.valueOf(timeStr.substring(5, 7));
        dateTime[3] = Byte.valueOf(timeStr.substring(8, 10));
        dateTime[4] = Byte.valueOf(timeStr.substring(11, 13));
        dateTime[5] = Byte.valueOf(timeStr.substring(14, 16));
        return dateTime;
    }

    /**
     * 将byte数组转换成字符串时间
     * <p>
     * 6个字节（2015年9月26日14点01分，14 0f 09 17 0e 01)
     *
     * @param data
     * @return
     */
    public static String byteArray6ToTime(byte[] data) {
        String result = "";
        if (data != null && data.length == 6) {
            String year1 = String.format(Locale.getDefault(), "%02d", data[0] & 0xff);
            String year2 = String.format(Locale.getDefault(), "%02d", data[1] & 0xff);
            String month = String.format(Locale.getDefault(), "%02d", data[2] & 0xff);
            String day = String.format(Locale.getDefault(), "%02d", data[3] & 0xff);
            String hour = String.format(Locale.getDefault(), "%02d", data[4] & 0xff);
            String minute = String.format(Locale.getDefault(), "%02d", data[5] & 0xff);
            result = year1 + year2 + "-" + month + "-" + day + " " + hour + ":" + minute;
        }
        return result;
    }

    /**
     * 计算两个日期之间相差的天数
     *
     * @param smdate 较小的时间
     * @param bdate  较大的时间
     * @return 相差天数
     * @throws ParseException
     */
    public static int daysBetween(Date smdate, Date bdate) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        smdate = sdf.parse(sdf.format(smdate));
        bdate = sdf.parse(sdf.format(bdate));
        Calendar cal = Calendar.getInstance();
        cal.setTime(smdate);
        long time1 = cal.getTimeInMillis();
        cal.setTime(bdate);
        long time2 = cal.getTimeInMillis();
        long between_days = (time2 - time1) / (1000 * 3600 * 24);
        return Integer.parseInt(String.valueOf(between_days));
    }

    /**
     * 字符串的日期格式的计算
     */
    public static int daysBetween(String smdate, String bdate) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar cal = Calendar.getInstance();
        cal.setTime(sdf.parse(smdate));
        long time1 = cal.getTimeInMillis();
        cal.setTime(sdf.parse(bdate));
        long time2 = cal.getTimeInMillis();
        long between_days = (time2 - time1) / (1000 * 3600 * 24);
        return Integer.parseInt(String.valueOf(between_days));
    }

    // 自研云对讲

    /**
     * 获取列表页显示的时间
     *
     * @param time 1970年1月1日开始的时间戳(ms)
     * @return 列表页显示的时间
     */
    public static String getListTime(Context context, long time) {
//        String listTime = "";
//        try {
//            SimpleDateFormat format = new SimpleDateFormat(FORMAT_YMDHMS);
//            String string = format.format(time);
//            Date date = format.parse(string);
//            Calendar calendar = Calendar.getInstance();
//            calendar.setTime(date);
//            if (DateUtils.isToday(string)) {// 是否是今天
//                listTime = DateUtils.dateToStr(date, "HH:mm");
//            } else if (calendar.get(Calendar.YEAR) == Calendar.getInstance().get(Calendar.YEAR)) {// 是否是今年
//                listTime = DateUtils.dateToStr(date, "MM-dd");
//            } else {
//                listTime = DateUtils.dateToStr(date, "yyyy-MM-dd");
//            }
//        } catch (Exception e) {
//        }

        String listTime = getTimePoint(context, time);
        return listTime;
    }

    /**
     * 获取详情页显示的时间
     *
     * @param time 1970年1月1日开始的时间戳(ms)
     * @return 详情页显示的时间
     */
    public static String getDetailsTime(long time) {
        String detailsTime = "";
        try {
            SimpleDateFormat format = new SimpleDateFormat(FORMAT_YMDHM);
            detailsTime = format.format(time);
        } catch (Exception e) {
        }
        return detailsTime;
    }

    /**
     * 获取详情页显示的时间
     *
     * @param time    1970年1月1日开始的时间戳(ms)
     * @param pattern 时间格式
     * @return 详情页显示的时间
     */
    public static String getDetailsTime(long time, String pattern) {
        String detailsTime = "";
        try {
            SimpleDateFormat format = new SimpleDateFormat(pattern);
            detailsTime = format.format(time);
        } catch (Exception e) {
        }
        return detailsTime;
    }

    // 获得当天0点时间
    public static long getTimesmorning() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTimeInMillis();
    }

    /**
     * 获取星期几
     *
     * @param date
     * @return
     */
    public static String getWeekOfDate(Date date) {
        return new SimpleDateFormat("EEEE", Locale.getDefault()).format(date);
    }

    /**
     * 时间格式：统一修改为：
     * ①当天，显示【时：分】如：14:12
     * ②昨天，显示【昨天】如：昨天
     * ③两天前一周内，显示【星期几】如：星期四
     * ④一周前，显示【年/月/日】如：18/5/5
     */
    public static String getTimePoint(Context context, long time) {
        Date date = new Date(time);
        DateFormat df;
        int day = (60 * 60 * 24) * 1000;
        String pointText;
        if (time <= (getTimesmorning() + day)) {
            // 时间点比当天零点早
            if (time < getTimesmorning()) {
                if (time >= getTimesmorning() - day) {// 比昨天零点晚
                    pointText = context.getString(R.string.yesterday);
                    return pointText;
                } else {// 比昨天零点早
                    Calendar calendar = Calendar.getInstance();
                    int nowWeek = calendar.get(Calendar.DAY_OF_WEEK) - 1;
                    if (nowWeek == 0) {
                        nowWeek = 7;
                    }
                    calendar.setTime(date);
                    int dataWeek = calendar.get(Calendar.DAY_OF_WEEK) - 1;
                    if (dataWeek == 0) {
                        dataWeek = 7;
                    }
                    if (time >= getTimesmorning() - 6 * day && nowWeek >= dataWeek) {
                        // 比七天前的零点晚，并且在当前时间这一周内，显示星期几
                        return getWeekOfDate(date);
                    } else {// 显示具体日期
                        df = new SimpleDateFormat("yyyy-MM-dd");
                        pointText = df.format(date);
                        return pointText;
                    }
                }
            } else {// 无日期时间,当天内具体时间
                df = new SimpleDateFormat("HH:mm");
                pointText = df.format(date);
                return pointText;
            }
        }
        df = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        pointText = df.format(date);
        return pointText;
    }

    // 2018升级项目
    public static String getVisitingTime(long startTime, long endTime) {
        String visitingTime = "";
        try {
            SimpleDateFormat format = new SimpleDateFormat(FORMAT_YMDHM);
            String start = format.format(startTime);
            SimpleDateFormat format1 = new SimpleDateFormat("HH:mm");
            String end = format1.format(endTime);
            visitingTime = start + "~" + end;
        } catch (Exception e) {
        }
        return visitingTime;
    }

    /**
     * 判断2个时间大小
     * HH:mm 格式（自己可以修改成想要的时间格式）
     *
     * @param startTime
     * @param endTime
     * @return 1 结束时间小于开始时间 2 开始时间与结束时间相同 3 结束时间大于开始时间
     */
    public static int getTimeCompareSize(String startTime, String endTime) {
        int i = 0;
        SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm");// 时-分
        try {
            Date date1 = dateFormat.parse(startTime);//开始时间
            Date date2 = dateFormat.parse(endTime);//结束时间
            if (date2.getTime() < date1.getTime()) {
                i = 1;
            } else if (date2.getTime() == date1.getTime()) {
                i = 2;
            } else if (date2.getTime() > date1.getTime()) {
                // 正常情况下的逻辑操作
                i = 3;
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return i;
    }

    public static String getTimeHMS(long time) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(FORMAT_HMS);
        return simpleDateFormat.format(new Date(time));
    }

    // 停车场-月租延期充值

    /**
     * 传入具体日期，返回具体日期增加一天
     *
     * @param date 日期(格式：2017-04-13)
     * @return str 日期(格式：2017-04-14)
     */
    public static String addOneDay(String date) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(FORMAT_YMD);
            Calendar rightNow = Calendar.getInstance();
            rightNow.setTime(sdf.parse(date));
            rightNow.add(Calendar.DAY_OF_MONTH, 1);
            return sdf.format(rightNow.getTime());
        } catch (Exception e) {
        }
        return "";
    }

    /**
     * 传入具体日期，返回具体日期增加n个月减少一天
     *
     * @param date   日期(格式：2017-04-13)
     * @param amount 几个月
     * @return str 日期(格式：2017-05-12)
     */
    public static String addMonthSubOneDay(String date, int amount) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(FORMAT_YMD);
            Calendar rightNow = Calendar.getInstance();
            rightNow.setTime(sdf.parse(date));
            rightNow.add(Calendar.MONTH, amount);
            rightNow.add(Calendar.DAY_OF_MONTH, -1);
            return sdf.format(rightNow.getTime());
        } catch (Exception e) {
        }
        return "";
    }

    /*我的钱包开始*/

    /**
     * 获取日期几号
     *
     * @param dateStr 日期字符串（格式：yyyy-MM-dd）
     * @return 日期几号
     */
    public static String getDay(String dateStr) {
        try {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(new SimpleDateFormat(FORMAT_YMD, Locale.getDefault()).parse(dateStr));
            return String.valueOf(calendar.get(Calendar.DAY_OF_MONTH));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return "";
    }

    /**
     * 获取周几
     *
     * @param dateStr
     * @return
     */
    public static String getWeek(String dateStr) {
        try {
            return new SimpleDateFormat("EEE", Locale.getDefault())
                    .format(new SimpleDateFormat(FORMAT_YMD, Locale.getDefault()).parse(dateStr));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return "";
    }
    /*我的钱包结束*/

    /*海外AVE开始*/
    public static TimeZone TIME_ZONE_0 = TimeZone.getTimeZone("GMT+00:00");// 0时区
    public static TimeZone TIME_ZONE_ROME = TimeZone.getTimeZone("Europe/Rome");// 意大利罗马时区

    /**
     * @param time 时间戳
     * @return 日期（格式：11.Nov 2019）
     */
    public static String getEnglishDate(long time, TimeZone zone) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("d.MMM.yyyy");
        simpleDateFormat.setTimeZone(zone);
        return simpleDateFormat.format(new Date(time));
    }

    public static String getHMS(long time, TimeZone zone) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(FORMAT_HMS);
        simpleDateFormat.setTimeZone(zone);
        return simpleDateFormat.format(new Date(time));
    }

    /**
     * 获取日期
     */
    public static String getDetailsEnglishDate(long time, TimeZone zone) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(FORMAT_DMYHMS);
        simpleDateFormat.setTimeZone(zone);
        return simpleDateFormat.format(new Date(time));
    }
    /*海外AVE结束*/
}
