package com.voicemessage.myapplication.utils;

import android.app.Instrumentation;
import android.view.KeyEvent;

/**
 * 模拟点击物理按键
 *
 * @author wlp 2018年10月29日 创建<br>
 */
public class Utils {

    /**
     * 模拟点击物理按键重置屏保倒计时
     */
    public static void simulateKeystroke() {
        new Thread(new Runnable() {
            public void run() {
                try {
                    Instrumentation inst = new Instrumentation();
                    inst.sendKeyDownUpSync(KeyEvent.KEYCODE_3D_MODE);
                } catch (Exception e) {
                }
            }
        }).start();
    }
}
