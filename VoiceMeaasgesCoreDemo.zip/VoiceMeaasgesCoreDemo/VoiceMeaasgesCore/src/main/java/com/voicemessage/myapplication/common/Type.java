package com.voicemessage.myapplication.common;

/**
 * 定义全局各种通用类型
 *
 * @author wlp 2018年10月29日 创建<br>
 */
public class Type {

    /**
     * ActionType 用于发送广播
     */
    public interface ActionType {
        //录音播放动画终止
        String RESET_ANIM_ACTION = "com.leelen.phone.RESET_ANIM_ACTION";
    }
}
