package com.voicemessage.myapplication.common;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

/**
 * 简单数据存储
 *
 * @author wlp 2018年10月19日 创建<br>
 */
public class Preferences {
    private static final String TAG = Preferences.class.getSimpleName();
    private static SharedPreferences.Editor mEditor = null;
    private static final boolean ISDEBUG = false;
    private static SharedPreferences mPrefs = null;
    private static Context mContext;

    // 屏保
    private static final String PREFERENCES_SCREEN_SAVER = "screen_saver";

    /**
     * 获取系统参数Preferences,
     *
     * @param context
     * @param prefersname
     */
    public static void init(Context context, String prefersname) {
        mContext = context;
        mPrefs = context.getSharedPreferences(prefersname, Context.MODE_PRIVATE);
        mEditor = mPrefs.edit();
    }

    /**
     * 提交保存整数值
     *
     * @param value
     */
    private static void editCommit(int value) {
        if (!mEditor.commit()) {
            if (ISDEBUG) {
                Log.i(TAG, "fail to save" + value);
            }
        }
    }

    /**
     * 屏保时间(秒)
     *
     * @param value
     */
    public static void setScreenSaverTime(int value) {
        mEditor.putInt(PREFERENCES_SCREEN_SAVER, value);
        editCommit(value);
    }

    public static int getScreenSaverTime() {
        return mPrefs.getInt(PREFERENCES_SCREEN_SAVER, 60);
    }
}
