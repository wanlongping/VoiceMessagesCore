package com.voicemessage.myapplication.presenter;

/**
 * MVP 的Presenter接口
 *
 * @author wlp 2018年11月9日 创建<br>
 */
public interface IRecordingPresenter {
    void addData(float seconds, String filePath);
    void addDataFinish();
}
