package com.voicemessage.myapplication.permission;

import android.os.Environment;
import net.sqlcipher.BuildConfig;
import java.io.File;

/**
 * 常量
 *
 * @author wlp 2018年9月28日 创建<br>
 */
public class CommunityConst {
    /**
     * 启用加密帐号
     */
    public static final boolean ENABLE_ENCRYPT_ACCOUNT = true;

    /**
     * 是否包含智能家居功能
     */
    public static final boolean CONTAIN_SMART_HOUSE = true;

    /**
     * 是否包含物业功能
     */
    public static final boolean CONTAIN_PROPERTY = true;

    /**
     * 主页菜单最多显示个数,不包含更多
     */
    public static final int HOME_MENU_NUM = 7;

    /**
     * SharePreference文件名
     */
    public static final String PREFS_NAME = "sp_community";

    /**
     * SD卡目录
     */
    public static final String SDCARD_DIR = Environment.getExternalStorageDirectory().getPath();
    public static final String SDCARD_PKG_DIR = SDCARD_DIR + File.separator + BuildConfig.APPLICATION_ID;
    public static final String PKG_USER_DIR = SDCARD_PKG_DIR + File.separator + "user";
    public static final String PKG_LOG_DIR = SDCARD_PKG_DIR + File.separator + "log";
    public static final String PKG_PENETRATION_LOG_DIR = PKG_LOG_DIR + File.separator + "penetrationlog";
    public static final String DOWN_LOAD_APK_DIR = SDCARD_PKG_DIR + File.separator + "update" + File.separator;
    public static final String PKG_CRASH_LOG_DIR = SDCARD_PKG_DIR + File.separator + "crash";
    /**
     * tutk穿透详细信息文件名称
     */
    public static final String TUTK_PENETRATION_LOG_FILE_NAME = PKG_PENETRATION_LOG_DIR +
            File.separator + DateUtils.getNow("yyyyMMddhhmmss") + ".log";

    public static final String UNIQUE_DEVICE_IDENTIFICATION = ".deviceIdentification";

    public static final String SDCARD_DATA = SDCARD_DIR + File.separator + "data" + File.separator;

    /**
     * app数据库文件
     */
    public static final String APP_DB_DIR = SDCARD_DATA + File.separator + "community_encrypt.db";

    /**
     * 信息最大条数
     */
    public static final int MESSAGE_MAX_SIZE = 1000;

    /**
     * 获取验证码倒计时
     */
    public static final int GET_VERIFY_CODE_TIME = 120;

    /**
     * 手机号长度
     */
    public static final int PHONE_NUM_LENGTH = 11;

    /**
     * 密码最短长度
     */
    public static final int MIN_PASSWORD_LENGTH = 8;

    /**
     * 密码最长长度
     */
    public static final int MAX_PASSWORD_LENGTH = 16;

    /**
     * 电话区号
     */
    public interface MobileAreaCode {
        /**
         * 中国电话区号
         */
        int CODE_CHINESE = 86;
    }

    /**
     * 验证码类型
     */
    public interface VerifyCodeType {
        /**
         * 帐号注册
         */
        int TYPE_ACCOUNT_REGISTER = 1;
        /**
         * 修改密码
         */
        int TYPE_MODIFY_PASSWORD = 2;
        /**
         * 修改手机号
         */
        int TYPE_MODIFY_PHONE_NUM = 6;
        /**
         * 设备授权
         */
        int TYPE_DEVICE_AUTH = 7;
        /**
         * 通知用户手动下载app
         */
        int TYPE_NOTIFY_MANUAL_DOWNLOAD_APP = 8;
    }

    /**
     * 验证方式
     */
    public interface VerifyModel {
        /**
         * 短信验证
         */
        int TYPE_SMS = 1;
        /**
         * 邮箱验证
         */
        int TYPE_MAIL = 2;
    }

    /**
     * 帐号类型
     */
    public interface AccountType {
        /**
         * 手机号
         */
        int TYPE_PHONE = 1;
        /**
         * 邮箱
         */
        int TYPE_MAIL = 2;
        /**
         * 自定义名称
         */
        int TYPE_CUSTOMIZE_NAME = 3;

        /**
         * 主帐号
         */
        int MAIN_ACCOUNT = 1;
        /**
         * 子帐号
         */
        int SON_ACCOUNT = 2;
    }

    /**
     * 注册人脸
     */
    public interface AddMemberConst {
        int SUCCESS = 1;
        int FALSE = -1;

        int ACCOUNT_NO_OPERATE_PERMISSION = -40000;//帐号无操作权限
        int HOUSE_HAVE_SUB_ACCOUNT = -40001;//住家底下还有子帐号
        int PERSON_HOUSE_ONLY_ACCOUNT = -40002;//一个人在同一个住家底下只能有一个帐号
        int APP_TIMEOUT = -40003;//弱同步超时

        int CHECK_FACE_FAIL = -40004;//图片质量不行
        int FACE_SERVER_NOT_LIVE = -40005;//人脸服务器不在线
        int FACE_SERVER_ADD_FACE_FAIL = -40006;//添加人脸失败
        int CERT_NUM_FORM_ERR = -50009;//证件号码格式错误

    }

    /**
     * 操作系统类型
     */
    public interface OsType {
        /**
         * Android手机
         */
        int TYPE_ANDROID_PHONE = 1;
        /**
         * Android pad
         */
        int TYPE_ANDROID_PAD = 2;
        /**
         * IPhone手机
         */
        int TYPE_IPHONE = 3;
        /**
         * IPAD
         */
        int TYPE_IPAD = 4;
        /**
         * 微信公众号
         */
        int TYPE_WECHAT = 5;
    }

    /**
     * 语言类型
     */
    public interface LanguageType {
        /**
         * 中文（简体）
         */
        String TYPE_CN = "zh-CN";
        /**
         * 中文（台湾）
         */
        String TYPE_TW = "zh-TW";
        /**
         * 中文（香港）
         */
        String TYPE_HK = "zh-HK";
        /**
         * 英文（美国）
         */
        String TYPE_US = "en-us";
    }

    /**
     * 密码最短长度
     */
    public static final int PASSWORD_SHORTEST_LENGTH = 8;

    public static final String XIAOMI_APP_ID = "2882303761517994832";
    public static final String XIAOMI_APP_KEY = "5741799472832";

    /**
     * 列表页每页数量
     */
    public static final int PAGE_COUNT = 50;
    /**
     * 界面最多显示数据条数
     */
    public static final int LIST_MAX_COUNT = 1000;

    /**
     * 数据库记录存储条数
     */
    public static final int DB_RECODE_SAVE_COUNT = 50;

    /**
     * MQTT登录用户名需要的ProductKey
     */
    public static final String PRODUCT_KEY = "a5e4x84a";

    /**
     * 列表页获取方式：1下拉刷新 2上拉加载更多
     */
    public interface ListGetType {
        int PULL_TO_REFRESH = 1;
        int PULL_UP_TO_LOAD_MORE = 2;
    }

    /**
     * 获取设备列表Type：2 云对讲相关业务（包括监视） 1 云门禁相关业务
     */
    public interface GetDeviceListType {
        int INTERCOM = 2;
        int ACCESS = 1;
    }

    /**
     * 远程开门状态：0表示失败，1表示成功
     */
    public interface RemoteOpenDoorStatus {
        int SUCCEED = 1;
        int FAILURE = 0;
    }

    /**
     * 第三方推送平台定义
     */
    public interface PushPlatform {
        int JPUSH = 1;
        int MIPUSH = 2;
        int HWPUSH = 3;
        int VIVO_PUSH = 6;
    }

    /**
     * 权限申请相关
     */
    public static final String KEY_PERMISSIONS_ARRAY = "key_permission_array";
    public static final String KEY_FIRST_MESSAGE = "key_first_message";
    public static final String KEY_ALWAYS_MESSAGE = "key_always_message";

    /**
     * 快捷控制通知栏id
     */
    public static final int QUICK_CONTROL_NOTIFICATION_ID = 1903;

    public interface PermissionCode {
        int PERMISSION_REQUEST_CODE = 0x01;

        //权限请求成功
        int CALL_BACK_RESULT_CODE_SUCCESS = 0x02;

        //权限请求失败
        int CALL_BACK_RESULE_CODE_FAILURE = 0x03;

        //跳转至权限请求界面requestcode
        int CALL_BACK_PERMISSION_REQUEST_CODE = 0x04;

        //无需申请
        int CALL_BACK_PERMISSION_NO_NEED_CODE = 0x05;
    }

    /**
     * 住家权限码
     */
    public interface HousePermissionCode {
        /**
         * 云门禁
         */
        int CODE_CLOUD_ACCESS_CONTROL = 1;

        /**
         * 云对讲
         */
        int CODE_CLOUD_INTERCOM = 2;

        /**
         * 转电话
         */
        int CODE_TRANSFER_CALL = 3;

        /**
         * 停车场
         */
        int CODE_PARKING_LOT = 4;

        /**
         * 呼梯
         */
        int CODE_CALL_ELEVATOR = 5;

        /**
         * 缴费
         */
        int CODE_PAYMENT = 6;

        /**
         * 报修
         */
        int CODE_REPAIR = 7;

        /**
         * 投诉
         */
        int CODE_COMPLAINT = 8;

        /**
         * 社区公告
         */
        int CODE_ANNOUNCEMENT = 9;

        /**
         * 访客预约
         */
        int VISITOR_RESERVATION = 10;

        /**
         * 社区IPC监控
         */
        int COMMUNITY_IPC_MONITOR = 11;
    }

    /**
     * 人员类型
     */
    public interface IdentityType {
        /**
         * 业主
         */
        String TYPE_OWNER = "owner";

        /**
         * 租客
         */
        String TYPE_TENANT = "tenant";
    }

    /**
     * MQTT命令字
     */
    public interface MqttCmd {
        /**
         * 强制下线
         */
        String FORCED_OFFLINE = "comm.forcedOffLine";
        /**
         * 异步应答
         */
        String ASYNC_ACK = "dmgr.asyncAck";
    }

    /**
     * MQTT命令字-强制下线-code
     */
    public interface ForcedOffline {
        /**
         * 异地登录
         */
        int REMOTE_LOGIN = 10013;
        /**
         * 密码被修改
         */
        int PASSWORD_CHANGED = 10019;
    }

    /**
     * 推送命令字
     */
    public interface PushCmd {
        int HOUSE_CHANGE_UNBIND = 2001;
        int HOUSE_CHANGE_BIND = 2002;
        int VISITOR_ARRIVE = 2003;//访客到达通知
        int ALARM = 1005;
        int CAR_ALARM = 1006;
        int PARKING_LOT_BILL = 1007;

        int REPAIR_DETAIL = 1101;//报修被处理
        int REPAIR_RESULT = 1102;//报修待确认

        int COMPLAINT_DETAIL = 1103;//投诉被处理
        int COMPLAINT_RESULT = 1104;//投诉待确认

        int BILL_GENERATION = 1105;//账单生成
        int PAY_SUCCESS = 1106;//缴费成功
        int OVERDUE_COLLECTION = 1107;//逾期催缴
        int PAYMENT_REMINDER = 1108;//缴费提醒
        int DEVICE_ALARM = 1109;//设备报警提醒

        int DOOR_OPEN_NOTIFY_ = 1111;//开门通知和门铃
        int SMART_HOUSE_SHARE_RESULT = 1112;//住家分享结果

        int LUXDOMO_PUSH_NOTIFY = 12;//家居网关推送通知
    }

    /**
     * sp_ble
     */
    public interface SpKeyBle {
        int NONE = 0;
        int BLE_SHAKE = 1;
        int BLE_AUTO = 2;
    }

    /**
     * 相册
     */
    public interface AlbumIntent {
        String PHOTO_PATH = "PHOTO_PATH";
        String PHOTO_DELETE = "PHOTO_DELETE";
        String PHOTO_SELECT = "PHOTO_SELECT";
        int IMAGE_HANDLE_RESULT_CODE = 1000;
    }

    // 蓝牙开门开始
    public static final byte[] PROTOCOL_VER = new byte[]{(byte) 0x01, (byte) 0x00};// 协议版本号
    public static final String GETBYTES_CHARSETNAME = "ISO-8859-1";

    /**
     * 协议命令字
     */
    public interface ProtocolCmd {
        byte[] HEARTBEAT = new byte[]{(byte) 0x04, (byte) 0x60};                // 心跳包
        byte[] PUSH_MSG = new byte[]{(byte) 0x00, (byte) 0x63};                 // 推送消息
        byte[] APP_LOGON = new byte[]{(byte) 0x02, (byte) 0x60};                // app 登录
        byte[] BIND_EXTENDSION = new byte[]{(byte) 0x03, (byte) 0x60};          // 绑定分机
        byte[] BIND_DONG_EXTENDSION = new byte[]{(byte) 0x10, (byte) 0x60};     // 绑定咚咚云分机
        byte[] UNBIND_EXTENDSION = new byte[]{(byte) 0x08, (byte) 0x60};        // 解除绑定分机
        byte[] RETRIEVE_MONLIST = new byte[]{(byte) 0x01, (byte) 0x61};         // 手机APP获取监视列表
        byte[] PASS_THROUGH = new byte[]{(byte) 0x00, (byte) 0x62};             // 网关透传
        byte[] UNLOCK = new byte[]{(byte) 0x0E, (byte) 0x01};                   // 开门协议
        byte[] REPEAT_LOGIN = new byte[]{(byte) 0x0C, (byte) 0x60};             // 同帐号重复登录推送
        byte[] REQUEST_PARAME = new byte[]{(byte) 0x05, (byte) 0x05};           // 请求参数
        byte[] REGIST_CARD = new byte[]{(byte) 0x0C, (byte) 0x1};               // 注册卡
        byte[] REMOTE_OPEN_LIST = new byte[]{(byte) 0x66, (byte) 0x01};         // 远程开门列表
        byte[] REMOTE_UNLOCK = new byte[]{(byte) 0x61, (byte) 0x02};            // 远程开门列表
        byte[] TCP_UNVARNISHED_TRANSMISSION = new byte[]{(byte) 0x13, (byte) 0x66};// TCP透传
    }

    /**
     * 请求参数类型
     * 1 请求分配ID
     * 2 请求分配IP
     * 3 请求是否进入注册状态
     */
    public interface RequestParameType {
        byte ID = 0x01;
        byte IP = 0x02;
        byte REGIST_STATE = 0x03;
    }

    /**
     * 卡类型
     * <p>
     * 0x00-IC卡
     * 0x01-ID卡
     * 0x02-身份证
     * 0x03-二维码
     * 0x04-人脸识别
     * 0x05-指纹识别
     * 0x06-蓝牙
     * 0x10-3B卡(3字节卡号为兼容原有存储模式)
     */
    public interface CardType {
        int IC = 0x00;
        int ID = 0x01;
        int SFZ = 0x02;
        int QR = 0x03;
        int FACE = 0x04;
        int FINGERPRINT = 0x05;
        int BLUETOOTH = 0x06;
        int THREEBYTE = 0x10;
    }

    /**
     * 注册卡应用类型
     * <p>
     * 1住户卡
     * 2物业卡
     * 3巡更卡
     * 4失效卡(己注册，但被注销或过期)
     * 5非法卡(该卡号不存在)
     * 6异常卡(有开启防复制情况下，该卡号存在，但不满足加密要求)
     */
    public interface CardUseType {
        byte HOUSEHOLD = 0x01;
        byte PROPERTY = 0x02;
        byte PATROL = 0x03;
        byte INVALID = 0x04;
        byte NOTEXIST = 0x05;
        byte EXCEPTION = 0x06;
    }

    /**
     * 证件类型
     * 0 身份证
     * 1 护照
     * 2 军官证
     * 10 其他
     */
    public interface CredentialsType {
        byte ID = 0x00;
        byte PASSPOR = 0x01;
        byte OFFICERS = 0x02;
        byte OTHER = 0x10;
    }
    // 蓝牙开门结束

    /**
     * 帐号管理相关
     */
    public interface AccountManagerConst {
        String ACTIVITY_TYPE = "ACTIVITY_TYPE";
        String ACCOUNT = "ACCOUNT";
        int ACTIVITY_ADD_ACCOUNT = 0;
        int ACTIVITY_ACCOUNT_DETAILS = 1;

        int PERMISSON_NO_REQUIRED = 0;
        int PERMISSON_REQUIRED = 1;
    }

    /**
     * 成员相关
     */
    public interface MemberConst {
        String ACTIVITY_TYPE = "ACTIVITY_TYPE";
        String MEMBER = "MEMBER";
        int ACTIVITY_ADD_MEMBER = 0;
        int ACTIVITY_MEMBER_DETAILS = 1;

        int MALE = 1;
        int FEMALE = 2;
    }

    /**
     * 升级相关
     */
    public interface UpdateConst {
        int EXIST_VERSION = 1;
        int FORCE_UPDATE = 1;
    }

    /**
     * 通知不同渠道id
     */
    public interface NotificationChannelId {
        String DOWNLOAD_PROGRESS_ID = "DOWNLOAD_PROGRESS_ID";// APP升级下载进度
        String SHORTCUTS_ID = "SHORTCUTS_ID";// 快捷操作
        String MESSAGE_ID = "MESSAGE_ID";// 消息
        String INTERCOM_ID = "INTERCOM_ID";// 对讲
    }

    /**
     * 已读未读常量
     */
    public interface ReadStatus {
        int UN_READ = 0;//未读
        int HAVE_READ = 1;//已读
    }

    /**
     * 车辆锁车状态
     */
    public interface CarLockStatus {
        int UNLOCKED = 1;//未锁定
        int LOCKED = 2;//已锁定
    }

    /**
     * 车辆锁定动作
     */
    public interface CarLockCtrl {
        int LOCK = 1;//锁定
        int UNLOCK = 2;//解锁
    }

    /**
     * 车辆出入场方向
     */
    public interface CarAccessDirection {
        int OUT = 1;//出场
        int INTO = 2;//入场
    }

    /**
     * 报警类型
     */
    public interface AlarmType {
        /**
         * 挟持报警
         */
        int SEIZED_ALARM = 2;
        /**
         * 防区报警
         */
        int AREA_ALARM = 8;
        /**
         * 防区布防
         */
        int PROTECTION_ALARM = 9;
        /**
         * 防区撤防
         */
        int REMOVAL_ALARM = 10;
        /**
         * 紧急求助
         */
        int DEVICE_EMERGENCY = 11;
    }

    /**
     * 报警探测器类型
     */
    public interface DetectorType {
        int EMERGENCY_BUTTON = 0;//紧急按钮
        int SMOKE_SENSOR = 1;//烟感
        int GAS = 2;//煤气泄漏
        int BODY_INFRARED = 3;//人体红外
        int DOOR_MAGNETIC = 4;//门磁
        int SECRET_HOLD = 5;//秘密挟持
        int WINDOW_MAGNETIC = 6;//窗磁
    }

    /**
     * 菜单服务类型
     */
    public interface MenuServiceType {
        int COMMUNITY = 0;//社区
        int SMART_HOME = 1;//智能家居
    }

    /**
     * 社区首页菜单类型
     */
    public interface MenuType {
        int MORE = -1;//更多
        int BLUETOOTH_OPEN_DOOR = 0;//蓝牙开门
        int QR_CODE_OPEN_DOOR = 1;//二维码开门
        int REMOTE_OPEN_DOOR = 2;//远程开门
        int INTERCOM_RECORD = 3;//对讲记录
        int ALARM = 12;//报警
        int CALL_ELEVATOR = 5;//呼梯
        int PARKING_LOT = 4;//停车场
        int VISITOR_RESERVATION = 10;//访客预约
        int PAYMENT = 6;//缴费
        int PROPERTY_WARRANTY = 7;//物业报修
        int COMPLAINT = 8;//投诉
        int BUTLER_SERVICE = 11;//管家服务
    }

    /**
     * 报修或投诉结果类型
     */
    public interface RepairOrComplaintResultType {
        int FIXED = 1;//已修好
        int NO_FIXED = 2;//未修好
    }

    /**
     * 报修或投诉状态
     */
    public interface RepairOrComplaintStatus {
        int TO_BE_PROCESSED = 1; //待处理
        int PROCESSING = 2; //处理中
        int TO_BE_CONFIRMED = 3; //待确认
        int COMPLETED = 4; //已完成
        int CLOSED = 5; //已关闭
    }

    /**
     * 子流程状态
     */
    public interface SonStatus {
        int EXAMINATION_PASSED = 1;//审核通过
        int EXAMINATION_FAIL = 2;//审核不通过
        int APPLY_TO_CLOSE = 3;//申请关闭中
    }

    /**
     * 数据字典类型
     */
    public interface DataDictionaryType {
        String REPAIR_TYPE = "repairArea";//报修类型
        String PERSONAL_REPAIR_TYPE = "repairTypeSelf";//个人报修
        String COMMON_REPAIR_TYPE = "repairTypePublic";//公共报修
    }

    /**
     * 添加图片标志
     */
    public static final String TAG_ADD_PICTURE = "addPicture";

    /**
     * 上传图片状态
     */
    public interface UploadPhotoStatus {
        /**
         * 未上传
         */
        int NO_UPLOAD = 0;
        /**
         * 正在上传
         */
        int UPLOADING = 1;
        /**
         * 上传成功
         */
        int SUCCEED = 2;
        /**
         * 上传失败
         */
        int FAILURE = -1;
    }

    /**
     * 报修区域
     */
    public interface RepairArea {
        int COMMON_AREA = 1;//公共区域
        int PERSONAL_AREA = 2;//个人报修
    }

    /**
     * 流程处理类型
     */
    public interface ProcessType {
        int SUBMIT = 1;//提交
        int DEAL_REPAIR = 2;//处理报修
        int DEAL_COMPLAINT = 3;//处理投诉
        int HAD_SEND_JOB = 4;//已派工
        int GRAB_ORDER = 5;//抢单
        int PROCESS_COMPLETE = 6;//处理完成
        int CONFIRM_REPAIR = 7;//确认报修
        int CONFIRM_COMPLAINT = 8;//确认投诉
        int PRAISE = 9;//评价
        int APPLY_CLOSE = 10;//申请关闭
        int EXAMINATION_PASSED = 11;//审核通过
        int EXAMINATION_FAIL = 12;//审核不通过
    }

    /**
     * 账单状态
     */
    public interface BillStatus {
        int UNPAID = 1; //未缴
        int PAID = 2; // 已缴
    }

    /**
     * 支付方式
     */
    public interface PayType {
        int WECHAT = 1; //微信
        int ALIPAY = 2; // 支付宝
        int OFFLINE_PAYMENT = 3; // 线下支付
    }

    /**
     * 车位
     */
    public interface ParkingSpace {
        int PROPERTY_PARKING_SPACE = 0;//产权车位
        int TEMPORARY_PARKING_SPACE = 1;//临停车位
        int RENT_PARKING_SPACE = 2;//租赁车位
        int CIVILIAN_PARKING_SPACE = 3;//人防车位
        int OTHER_PARKING_SPACE = 4;//其他车位
    }

    /**
     * 权限状态
     */
    public interface PermissionState {
        int NORMAL = 1;//正常使用
        int OVERDUE = 2;//逾期
        int NO_PERMISSION = 3;//未开通

    }

    /**
     * 访客预约状态
     */
    public interface EffectiveStatus {
        int PENDING = 1;//待生效
        int IN_FORCE = 2;//已生效
        int EXPIRED = 3;//已失效
        int CANCELED = 4;//已取消
    }

    /**
     * 访客预约方案码
     */
    public interface ReservationSchemeCode {
        long QRCODE = 1;//二维码
        long DYNAMIC_PASSWORD = 2;//待完成
        long CAR = 3;//已完成
        long FACE = 4;//人脸
    }

    /**
     * 停车场方案码
     */
    public interface Park {
        int Monthly_Rent_Deferred = 1;// 月租车延期
    }
}
