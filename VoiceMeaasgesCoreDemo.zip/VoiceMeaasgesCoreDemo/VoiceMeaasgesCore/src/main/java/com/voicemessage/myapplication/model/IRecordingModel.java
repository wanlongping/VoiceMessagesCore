package com.voicemessage.myapplication.model;

/**
 * MVP 的Model层接口
 *
 * @author wlp 2018年11月19日 创建<br>
 */
public interface IRecordingModel {
    void addData(float seconds, String filePath);
}
