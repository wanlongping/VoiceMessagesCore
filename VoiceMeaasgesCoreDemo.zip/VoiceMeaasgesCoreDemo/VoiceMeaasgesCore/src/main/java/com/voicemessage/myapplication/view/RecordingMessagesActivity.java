package com.voicemessage.myapplication.view;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.voicemessage.myapplication.R;
import com.voicemessage.myapplication.bean.Record;
import com.voicemessage.myapplication.permission.CommunityConst;
import com.voicemessage.myapplication.common.Constant;
import com.voicemessage.myapplication.common.Preferences;
import com.voicemessage.myapplication.dao.RecordingDao;
import com.voicemessage.myapplication.manager.MediaManager;
import com.voicemessage.myapplication.permission.PermissionActivity;
import com.voicemessage.myapplication.presenter.IRecordingPresenter;
import com.voicemessage.myapplication.presenter.RecordingPresenterImpl;
import com.voicemessage.myapplication.utils.FileUtils;
import com.voicemessage.myapplication.permission.OSUtils;
import com.voicemessage.myapplication.utils.PermissionHelper;

import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static com.voicemessage.myapplication.common.Type.ActionType.RESET_ANIM_ACTION;
import static com.voicemessage.myapplication.common.Constant.PREFS_NAME;
import static com.voicemessage.myapplication.utils.FileUtils.deleteDirectory;
import static com.voicemessage.myapplication.view.RecordingMessagesAdapter.mRecords;

/**
 * 录音留言中心
 *
 * @author wlp 2018年10月26日 创建<br>
 */
public class RecordingMessagesActivity extends Activity implements View.OnClickListener, IRecordingActivityView{

    private static final String TAG = RecordingMessagesActivity.class.getSimpleName();
    //清空记录按钮
    private ImageView imClean;
    //显示录音总时长的textview
    private TextView tvTotalRecordTime;
    //录音记录列表
    private ListView mEmLvRecodeList;
    //显示录音信息弹框布局
    private LinearLayout mRecording;
    //隐藏录音信息弹框布局
    private LinearLayout mCancelRecording;
    //显示录音时间过短对话框
    private LinearLayout mTimeTooShort;
    private LinearLayout mNoRecord;
    public LinearLayout mPromptBox;
    public boolean isCheckBoxChecked;
    public CheckBox mCheckBox;
    private IRecordingPresenter mPresenter;
    //录音按钮
    private AudioRecordButton mEmTvBtn;
    //db 操作
    public RecordingDao mRecordingDao;
    //权限请求类
    PermissionHelper mHelper;
    //留言列表适配器
    RecordingMessagesAdapter mRecordingMessagesAdapter;

    private static SharedPreferences mPrefs = null;
    private static SharedPreferences.Editor mEditor = null;
    private Context mContext;
    private boolean isClose = false;
    BroadcastReceiver mResetAnimReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // preference
        Preferences.init(this, Constant.PREFS_NAME);
        mContext = this;
        setContentView(R.layout.activity_recording_messages);
        mPresenter = new RecordingPresenterImpl(this, this);
        imClean = (ImageView) findViewById(R.id.bt_clean);
        imClean.setOnClickListener(this);

        initView();
        initData();
        initAdapter();
        initListener();

        //设置进度条倒计时时间
        mEmTvBtn.setCountdownTime(60000);
        //注册按钮按下录音时取消录音播放动画显示的广播
        initResetAnimReceiver();
        checkPermission();
    }
    /**
     * 检查权限
     */
    private void checkPermission() {
        String[] permissionArray;
        if (OSUtils.isVivo() || OSUtils.isFlyme() || OSUtils.isMotorola()) {
            permissionArray = new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS,
//                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.RECORD_AUDIO,
//                    Manifest.permission.CAMERA,
//                    Manifest.permission.ACCESS_FINE_LOCATION
            };
        } else {
            permissionArray = new String[]{Manifest.permission.READ_PHONE_STATE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_CONTACTS,
                    Manifest.permission.WRITE_CONTACTS,
//                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.RECORD_AUDIO,
//                    Manifest.permission.CAMERA,
//                    Manifest.permission.ACCESS_FINE_LOCATION
            };
        }
        Intent intent = new Intent(this, PermissionActivity.class);
        intent.putExtra(CommunityConst.KEY_PERMISSIONS_ARRAY, permissionArray);
        startActivityForResult(intent, CommunityConst.PermissionCode.CALL_BACK_PERMISSION_REQUEST_CODE);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    private void initView() {
        mEmLvRecodeList = (ListView) findViewById(R.id.em_lv_recodeList);
        mEmTvBtn = (AudioRecordButton) findViewById(R.id.iv_record);
        mEmTvBtn.setRecordingMessagesActivity(this);
        mRecording = (LinearLayout) findViewById(R.id.recording);
        mCancelRecording = (LinearLayout) findViewById(R.id.cancel_recording);
        mTimeTooShort = (LinearLayout) findViewById(R.id.too_short_recording);

        //提示引导框
        mPromptBox = (LinearLayout) findViewById(R.id.prompt_box);
        mCheckBox = (CheckBox) findViewById(R.id.check_box);

        tvTotalRecordTime = (TextView) findViewById(R.id.total_recording_time);

        mNoRecord = (LinearLayout) findViewById(R.id.no_record);

        //判断checkbox被勾选与否的状态，若被勾选，则将isCheckBoxChecked置为true,若未被勾选，则将isCheckBoxChecked置为false
        mCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    isCheckBoxChecked = true;
                    //设置延时十秒让引导框自动消失
                    mPromptBox.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            mPromptBox.setVisibility(GONE);
                        }
                    },1000);

                    mPrefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                    mEditor = mPrefs.edit();
                    mEditor.putBoolean("isCheckBoxChecked", isCheckBoxChecked);
                    mEditor.commit();
                }else{
                    isCheckBoxChecked = false;
                }
            }
        });
    }

    private void initData() {
        //初始化RecordingDao
        mRecordingDao = new RecordingDao(this);
    }

    public void initAdapter() {
        if (mRecordingMessagesAdapter == null) {
            mRecordingMessagesAdapter = new RecordingMessagesAdapter(this, mRecords,mEmTvBtn);
            mEmLvRecodeList.setAdapter(mRecordingMessagesAdapter);
        }
        //开始获取数据库数据
        mRecords.clear();
        List<Record> records = mRecordingDao.query();

        //将留言信息列表按照时间的顺序来排序显示
        Collections.sort(records, new Comparator<Record>() {
            @Override
            public int compare(Record o1, Record o2) {
                if (new Date(Long.valueOf(o1.getRecordTime())).before(new Date(Long.valueOf(o2.getRecordTime())))) {
                    return -1;
                }
                return 1;
            }
        });

        mRecords.addAll(records);
        if (!(records == null || records.isEmpty())) {
            //控制显示每隔10分种显示录音时间
            int mPosition = 0;
            for (int i = 0; i < records.size(); i ++) {
                if(i == 0) {
                    mPosition = 0;
                    mRecords.get(i).setShowTime(true);
                }else {
                    if(Math.abs(Long.valueOf(mRecords.get(i).getRecordTime()) - Long.valueOf(mRecords.get(mPosition).getRecordTime())) < 600000){
                        mRecords.get(i).setShowTime(false);
                    }else{
                        //设置显示录音的时间
                        mPosition = i;
                        mRecords.get(i).setShowTime(true);
                    }
                }
            }
        }else{
            //隐藏列表界面
            mEmLvRecodeList.setVisibility(GONE);
            //显示录音数据为空的界面
            mNoRecord.setVisibility(VISIBLE);
        }
        mRecordingMessagesAdapter.notifyDataSetChanged();
        if (!mRecords.isEmpty()) {
            mEmLvRecodeList.setSelection(mRecords.size() - 1); //滚动到最后一个条目的方法
        }
    }

    private void initListener() {
        mEmTvBtn.setHasRecordPromission(false);
        //授权处理
        mHelper = new PermissionHelper(this);
        mHelper.requestPermissions("请授予[录音]，[读写]权限，否则无法录音",
                new PermissionHelper.PermissionListener() {
                    @Override
                    public void doAfterGrand(String... permission) {
                        mEmTvBtn.setHasRecordPromission(true);
                        mEmTvBtn.setAudioFinishRecorderListener(new AudioRecordButton.AudioFinishRecorderListener() {
                            @Override
                            public void onFinished(float seconds, String filePath) {
                                //添加录音信息的各数据
                                mPresenter.addData(seconds, filePath);
                            }
                        });
                    }

                    @Override
                    public void doAfterDenied(String... permission) {
                        mEmTvBtn.setHasRecordPromission(false);
                        Toast.makeText(RecordingMessagesActivity.this, "请授权，否则无法录音", Toast.LENGTH_SHORT).show();
                    }
                }, Manifest.permission.RECORD_AUDIO, Manifest.permission.WRITE_EXTERNAL_STORAGE);
    }

    /**
     * 接收音各种中断录音播放的中断，停止录音播放是的信号栏动画显示
     */
    public void initResetAnimReceiver() {
        mResetAnimReceiver= new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (TextUtils.equals(action, RESET_ANIM_ACTION)) {
                    mRecordingMessagesAdapter.resetAnim();
                }
            }
        };

        //注册按钮按下录音时取消录音播放动画显示的广播
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(RESET_ANIM_ACTION);
        registerReceiver(mResetAnimReceiver,intentFilter);
    }

    @Override
    public void addDataFinish() {
        initAdapter();
        mRecordingMessagesAdapter.notifyDataSetChanged();
        mEmLvRecodeList.setSelection(mRecords.size() - 1);
        //显示列表界面
        mEmLvRecodeList.setVisibility(VISIBLE);
        //隐藏录音数据为空的界面
        mNoRecord.setVisibility(GONE);
    }

    /**
     * 直接把参数交给mHelper就行了
     * @param requestCode
     * @param permissions
     * @param grantResults
     */
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        mHelper.handleRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onPause() {
        super.onPause();
        MediaManager.pause();
        //如果时间不足两秒则不保存录音
        if(mEmTvBtn.mTime < 2f){
            mEmTvBtn.interruptAlarmDeal();
            return;
        }
        mEmTvBtn.saveRecordFile();
    }

    @Override
    protected void onStop() {
        super.onStop();
        //发送停止录音播放动画显示的广播
        sendBroadcast(new Intent(RESET_ANIM_ACTION));
        if(isClose){
            MediaManager.pause();
            mEmTvBtn.interruptDeal();
            return;
        }
        MediaManager.pause();
        //如果时间不足两秒则不保存录音
        if(mEmTvBtn.mTime < 2f){
            mEmTvBtn.interruptAlarmDeal();
            return;
        }
        mEmTvBtn.saveRecordFile();
    }

    public RecordingDao getmRecordingDao() {
        return mRecordingDao;
    }

    public void setmRecordingDao(RecordingDao recordingDao) {
        this.mRecordingDao = recordingDao;
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.bt_clean) {//停止掉当前正在播放的留言
            MediaManager.release();
            //终止正在录音的操作
            MediaManager.pause();
            if (mEmTvBtn.isRecording) {
                mEmTvBtn.interruptCleanDeal();
            }
            //自定义AlertDialog对话框
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            LayoutInflater inflater = LayoutInflater.from(this);
            View v1 = inflater.inflate(R.layout.alertdialog_recording, null);
            TextView title = (TextView) v1.findViewById(R.id.title);
            TextView no = (TextView) v1.findViewById(R.id.no);
            TextView yes = (TextView) v1.findViewById(R.id.yes);
            final Dialog dialog = builder.create();
            dialog.show();
            dialog.getWindow().setContentView(v1);
            //通过代码设置AlertDialog对话框的宽和高
            WindowManager.LayoutParams p = dialog.getWindow().getAttributes(); //获取对话框当前的参数值
            p.height = 500;
            p.width = 900;
            dialog.getWindow().setAttributes(p);
            //设置AlertDialog对话框在屏幕的中央显示
            dialog.getWindow().setGravity(Gravity.CENTER);
            //设置对话框的按钮点击事件
            //“取消”
            title.setText(R.string.record_whether_to_empty_all_records);
            no.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });
            //“确定”
            yes.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                    //获取录音保存位置
                    String dir = FileUtils.getAppRecordDir(RecordingMessagesActivity.this).toString();
                    //彻底清除音频文件，防止系统内存不足
                    deleteDirectory(dir);
                    //清空所有的留言记录
                    mRecordingDao.clearTable();
                    initAdapter();
                }
            });
        }
    }

    /**
     * 显示录音信息弹框
     */
    public void showRecordingDialog() {
        mRecording.setVisibility(VISIBLE);
        mCancelRecording.setVisibility(GONE);
    }

    /**
     * 隐藏录音信息弹框
     */
    public void dimissRecordingDialog() {
        mRecording.setVisibility(GONE);
    }

    /**
     * 取消录音信息弹框
     */
    public void wantToCancelRecordingDialog() {
        mRecording.setVisibility(GONE);
        mCancelRecording.setVisibility(VISIBLE);
    }

    /**
     * 隐藏取消录音信息弹框
     */
    public void dimissWantToRecordingDialog() {
        mCancelRecording.setVisibility(GONE);
    }

    /**
     * 录音时间过短
     */
    public void timeTooShort() {
        mRecording.setVisibility(GONE);
        mCancelRecording.setVisibility(GONE);
        mTimeTooShort.setVisibility(VISIBLE);
    }

    /**
     * 隐藏录音时间过短对话框
     */
    public void dismissTimeTooShortDialog() {
        mTimeTooShort.setVisibility(GONE);
    }

    /**
     * 显示总的录音时长
     * @return
     */
    public TextView getTotalRecordTimeTxt() {
        return tvTotalRecordTime;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        unregisterReceiver(mResetAnimReceiver);
    }
}
