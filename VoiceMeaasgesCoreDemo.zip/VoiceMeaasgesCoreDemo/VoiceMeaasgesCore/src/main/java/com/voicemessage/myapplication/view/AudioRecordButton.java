package com.voicemessage.myapplication.view;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import androidx.appcompat.widget.AppCompatButton;

import com.voicemessage.myapplication.R;
import com.voicemessage.myapplication.common.Preferences;
import com.voicemessage.myapplication.manager.AudioManager;
import com.voicemessage.myapplication.manager.MediaManager;
import com.voicemessage.myapplication.utils.FileUtils;
import com.voicemessage.myapplication.utils.Utils;

import static com.voicemessage.myapplication.common.Type.ActionType.RESET_ANIM_ACTION;
import static com.voicemessage.myapplication.common.Constant.PREFS_NAME;

/**
 * 自定义录音按钮控件，包括进度条、点击、响应、与弹出对话框交互等操作
 *
 * @author wlp 2018年10月23日 创建<br>
 */
public class AudioRecordButton extends AppCompatButton implements AudioManager.AudioStageListener {
    //三个对话框的状态常量
    private static final int STATE_NORMAL = 1;
    private static final int STATE_RECORDING = 2;
    private static final int STATE_WANT_TO_CANCEL = 3;
    // 三个状态
    private static final int MSG_AUDIO_PREPARED = 0X110;
    private static final int MSG_VOICE_CHANGE = 0X111;
    private static final int MSG_DIALOG_DIMISS = 0X112;
    //垂直方向滑动取消的临界距离
    private static final int DISTANCE_Y_CANCEL = 50;
    //取消录音的状态值
    private static final int MSG_VOICE_STOP = 4;
    //当前状态
    private int mCurrentState = STATE_NORMAL;
    // 正在录音标记
    public boolean isRecording = false;
    //核心录音类
    private AudioManager mAudioManager;
    //当前录音时长
    public float mTime = 0;
    // 是否触发了onlongclick，准备好了
    private boolean mReady;
    //标记是否强制终止
    private boolean isOverTime = false;
    //最大录音时长（单位:s）。def:60s
    private int mMaxRecordTime = 60;
    //上下文
    Context mContext;
    //提醒倒计时
    private int mRemainedTime = 10;
    //设置是否允许录音,这个是是否有录音权限
    private boolean mHasRecordPromission = true;
    private RecordingMessagesActivity mRecordingMessagesActivity;
    private AudioFinishRecorderListener mListener;
    //进度条相关定义
    private Paint paint;
    private int curAngle;
    private int curPercentate;
    private int radius;
    private int startAngle;
    private int countdownTime;
    private CountDownTimer countDownTimer;
    private static SharedPreferences mPrefs = null;

    public void setRecordingMessagesActivity(RecordingMessagesActivity activity) {
        mRecordingMessagesActivity = activity;
    }

    public boolean isHasRecordPromission() {
        return mHasRecordPromission;
    }

    public void setHasRecordPromission(boolean hasRecordPromission) {
        this.mHasRecordPromission = hasRecordPromission;
    }

    @Override
    public boolean isInEditMode() {
        return true;
    }

    public AudioRecordButton(Context context) {
        this(context, null);
        //初始化进度条
        initProgressBar();
    }

    public AudioRecordButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
        //获取录音保存位置
        String dir = FileUtils.getAppRecordDir(mContext).toString();
        Log.e(mContext.toString(), "获取到的录音保存位置是：" + dir);
        //实例化录音核心类
        mAudioManager = AudioManager.getInstance(dir);
        mAudioManager.setOnAudioStageListener(this);
        //按钮长按事件监听
        setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (isHasRecordPromission()) {
                    mReady = true;
                    mAudioManager.prepareAudio();
                    changeState(STATE_RECORDING);
                    //播放前重置,长按按钮录音时停止留言播放
                    MediaManager.pause();
                    //按钮长按的时候进度条开始加载并计算时间
//                    countDown(countdownTime);
                    //设置按钮在长按过程中保证屏幕不进入屏保
                    timingAnalogKey();
                    return false;
                } else {
                    return true;
                }
            }
        });

        //进度条
        TypedArray array = context.obtainStyledAttributes(attrs, R.styleable.CiclePercentView);
        radius = array.getInt(R.styleable.CiclePercentView_radius,67);
        array.recycle();
        //进度条初始化
//        initProgressBar();
    }

    /**
     * 进度条的初始化
     */
    private void initProgressBar() {
        paint = new Paint();
        paint.setColor(Color.BLUE);
        paint.setStyle(Paint.Style.STROKE);
        paint.setAntiAlias(true);
        paint.setStrokeWidth(8);
        //起始角度
        startAngle = -90;
    }

//    /**
//     * 进度条绘制
//     * @param canvas
//     */
//    @Override
//    protected void onDraw(Canvas canvas) {
//        super.onDraw(canvas);
//        //画圆弧
//        RectF rectf = new RectF(1,1,dp2px(radius),dp2px(radius));
//        canvas.drawArc(rectf,startAngle,curAngle,false,paint);
//    }
//
//    /**
//     * 进度条加载百分比控制
//     * @param percentage
//     */
//    private void percentToAngle(int percentage){
//        curAngle =  (int) (percentage/100f*360);
//        invalidate();
//    }

    /**
     * 进度条按下时间计算
     * @param countdownTime
     */
    public void setCountdownTime(int countdownTime){
        this.countdownTime = countdownTime;
    }

//    /**
//     * 进度条计算按下时间
//     * @param totalTime
//     */
//    public void countDown(final int totalTime){
//        countDownTimer = new CountDownTimer(totalTime, (long)(totalTime/100f)) {
//            @Override
//            public void onTick(long millisUntilFinished) {
//                curPercentate = (int) ((totalTime-millisUntilFinished)/(float)totalTime*100);
//                percentToAngle(curPercentate);
//            }
//            @Override
//            public void onFinish() {
//                curPercentate = 0;
//                percentToAngle(curPercentate);
//            }
//        }.start();
//    }

//    /**
//     * 进度条尺寸控制
//     * @param dp
//     * @return
//     */
//    private int dp2px(int dp){
//        return (int) (getContext().getResources().getDisplayMetrics().density*dp + 0.5);
//    }
//
    public interface AudioFinishRecorderListener {
        void onFinished(float seconds, String filePath);
    }

    public void setAudioFinishRecorderListener(AudioFinishRecorderListener listener) {
        mListener = listener;
    }

    /**
     * 获取音量大小的runnable
     */
    private Runnable mGetVoiceLevelRunnable = new Runnable() {

        @Override
        public void run() {
            while (isRecording) {
                try {
                    //最长mMaxRecordTimes
                    if (mTime > mMaxRecordTime) {
                        mStateHandler.sendEmptyMessage(MSG_VOICE_STOP);
                        return;
                    }
                    Thread.sleep(100);
                    mTime += 0.1f;
                    mStateHandler.sendEmptyMessage(MSG_VOICE_CHANGE);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    };

    @SuppressLint("HandlerLeak")
    private final Handler mStateHandler = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MSG_AUDIO_PREPARED:
                    // 显示应该是在audio end prepare之后回调
                    isRecording = true;
                    mRecordingMessagesActivity.showRecordingDialog();
                    new Thread(mGetVoiceLevelRunnable).start();
                    // 需要开启一个线程来变换音量
                    break;
                case MSG_VOICE_CHANGE:
                    //剩余10s
                    showRemainedTime();
                    break;
                case MSG_DIALOG_DIMISS:
                    //录音时间太短
                    mRecordingMessagesActivity.dismissTimeTooShortDialog();
                    break;
                case MSG_VOICE_STOP:
                    //超时
                    isOverTime = true;
                    mRecordingMessagesActivity.dimissRecordingDialog();
                    // release释放一个mediarecorder
                    mAudioManager.release();
                    mListener.onFinished(mTime, mAudioManager.getCurrentFilePath());
                    // 恢复标志位
                    reset();
                    break;
            }
        }
    };

    /**
     * 显示录音总时长
     */
    private void showRemainedTime() {
        int recordingTotalTime = (int) mTime;
        if(recordingTotalTime < mRemainedTime) {
            mRecordingMessagesActivity.getTotalRecordTimeTxt().setText("00:0" + recordingTotalTime);
        }else if(mRemainedTime<=recordingTotalTime && recordingTotalTime < mMaxRecordTime){
            mRecordingMessagesActivity.getTotalRecordTimeTxt().setText("00:" + recordingTotalTime);
        }else if(recordingTotalTime == mMaxRecordTime){
            mRecordingMessagesActivity.getTotalRecordTimeTxt().setText("01:" + recordingTotalTime);
        }
    }

    /**
     * 在这里面发送一个handler的消息
     */
    @Override
    public void wellPrepared() {
        mStateHandler.sendEmptyMessage(MSG_AUDIO_PREPARED);
    }

    /**
     * 手指滑动监听
     * @param event
     * @return
     */
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getAction();
        int x = (int) event.getX();
        int y = (int) event.getY();

        switch (action) {
            case MotionEvent.ACTION_DOWN:
                break;
            case MotionEvent.ACTION_MOVE:
                if (isRecording) {
                    // 根据x，y来判断用户是否想要取消
                    if (wantToCancel(x, y)) {
                        changeState(STATE_WANT_TO_CANCEL);
                    } else {
                        if (!isOverTime)
                            changeState(STATE_RECORDING);
                    }
                }
                break;
            case MotionEvent.ACTION_UP:
                //发送停止录音播放动画显示的广播
                getContext().sendBroadcast(new Intent(RESET_ANIM_ACTION));
                //取消控制不进入屏保模式
                mKeyHandler.removeCallbacks(mKeyRunnable);
                // 首先判断是否有触发onlongclick事件，没有的话直接返回reset
                if (!mReady) {
                    reset();
                    return super.onTouchEvent(event);
                }
                // 如果按的时间太短，还没准备好或者时间录制太短不足3秒，就离开了，则显示这个dialog
                if (!isRecording || mTime < 2f) {
                    mRecordingMessagesActivity.timeTooShort();
                    mAudioManager.cancel();
                    mStateHandler.sendEmptyMessageDelayed(MSG_DIALOG_DIMISS, 500);// 持续1.3s
                } else if (mCurrentState == STATE_RECORDING) {//正常录制结束
                    if (isOverTime) return super.onTouchEvent(event);//超时
                    //隐藏录音动画框
                    mRecordingMessagesActivity.dimissRecordingDialog();
                    //判断checkbox是否勾选，如果勾选，则不显示引导框，如果没被勾选，则每次录完依旧显示引导框，且延时十秒自动隐藏
                    mPrefs = mContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
                    boolean isCheckBoxCheckedState = mPrefs.getBoolean("isCheckBoxChecked",false);
                    if(isCheckBoxCheckedState){
                        mRecordingMessagesActivity.mPromptBox.setVisibility(GONE);
                    }else{
                        //显示引导框
                        mRecordingMessagesActivity.mPromptBox.setVisibility(VISIBLE);
                        //设置延时十秒让引导框自动消失
                        mRecordingMessagesActivity.mPromptBox.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                mRecordingMessagesActivity.mPromptBox.setVisibility(GONE);
                            }
                        },10000);
                    }
                    // release释放一个mediarecorder
                    mAudioManager.release();
                    // 并且callbackActivity，保存录音
                    if (mListener != null) {
                        mListener.onFinished(mTime, mAudioManager.getCurrentFilePath());
                    }
                } else if (mCurrentState == STATE_WANT_TO_CANCEL) {
                    // cancel
                    mAudioManager.cancel();
                    mRecordingMessagesActivity.dimissWantToRecordingDialog();
                }
                // 恢复标志位
                reset();
                //进度条计时取消
                countDownTimer.cancel();
                curPercentate = 0;
//                percentToAngle(curPercentate);
                break;
        }
        return super.onTouchEvent(event);
    }

    /**
     * 回复标志位以及状态
     */
    private void reset() {
        isRecording = false;
        changeState(STATE_NORMAL);
        mReady = false;
        mTime = 0;
        isOverTime = false;
    }

    private boolean wantToCancel(int x, int y) {
        // 判断是否在左边，右边，上边，下边
        if (x < 0 || x > getWidth()) {
            return true;
        }
        if (y < -DISTANCE_Y_CANCEL || y > getHeight() + DISTANCE_Y_CANCEL) {
            return true;
        }
        return false;
    }

    private void changeState(int state) {
        if (mCurrentState != state) {
            mCurrentState = state;
            switch (mCurrentState) {
                case STATE_NORMAL:
                    setBackground(mContext.getResources().getDrawable(R.mipmap.recording_btn));
                    break;
                case STATE_RECORDING:
                    setBackground(mContext.getResources().getDrawable(R.mipmap.recording_down));
                    if (isRecording) {
                        // 复写dialog.recording();
                        mRecordingMessagesActivity.showRecordingDialog();
                    }
                    break;
                case STATE_WANT_TO_CANCEL:
                    setBackground(mContext.getResources().getDrawable(R.mipmap.recording_down));
                    // dialog want to cancel
                    mRecordingMessagesActivity.wantToCancelRecordingDialog();
                    break;
            }
        }
    }

    @Override
    public boolean onPreDraw() {
        return false;
    }

    /**
     * 计时模拟点击,保证屏幕在录音过程中不进入屏保
     */
    private void timingAnalogKey() {
        int sst = Preferences.getScreenSaverTime();
        if (sst < 0) {
            return;
        }
        mKeyHandler.removeCallbacks(mKeyRunnable);
        // (sst - 1) * 1000
        mScreenSaverTime = 1000;
        mKeyHandler.post(mKeyRunnable);
    }
    // 延时模拟按键点击来不进入屏保
    private Handler mKeyHandler = new Handler();
    private int mScreenSaverTime = 0;

    private Runnable mKeyRunnable = new Runnable() {
        @Override
        public void run() {
            //模拟点击物理按键重置屏保倒计时
            Utils.simulateKeystroke();
            mKeyHandler.postDelayed(mKeyRunnable, mScreenSaverTime);
        }
    };


    /**
     *按钮抬起时保存录音留言的方法
     */
    public void saveRecordFile() {
        // 首先判断是否有触发onlongclick事件，没有的话直接返回reset
        if (!mReady) {
            reset();
        }
        //正常录制结束
        if (mCurrentState == STATE_RECORDING ) {
            //隐藏录音动画框
            mRecordingMessagesActivity.dimissRecordingDialog();
            // release释放一个mediarecorder
            mAudioManager.release();
            // 并且callbackActivity，保存录音
            if (mListener != null) {
                mListener.onFinished(mTime, mAudioManager.getCurrentFilePath());
            }
        }
        // 恢复标志位
        reset();
        //进度条计时取消
        countDownTimer.cancel();
        curPercentate = 0;
//        percentToAngle(curPercentate);
    }

    /**
     * 录音被对讲，按钮关闭中断处理的方法
     */
    public void interruptDeal() {
        //隐藏录音动画框
        mRecordingMessagesActivity.dimissRecordingDialog();
        // release释放一个mediarecorder
        mAudioManager.release();
        // 恢复标志位
        reset();
    }

    /**
     * 录音被安防报警中断处理的方法
     */
    public void interruptAlarmDeal() {
        //隐藏录音动画框
        mRecordingMessagesActivity.dimissRecordingDialog();
        // release释放一个mediarecorder
        mAudioManager.release();
        // 恢复标志位
        reset();
        //进度条计时取消
        if(countDownTimer != null){
            countDownTimer.cancel();
        }
        curPercentate = 0;
//        percentToAngle(curPercentate);
    }

    /**
     * 录音被清空消息中断处理的方法
     */
    public void interruptCleanDeal() {
        //隐藏录音动画框
        mRecordingMessagesActivity.dimissRecordingDialog();
        //release释放一个mediarecorder
        mAudioManager.release();
        //并且callbackActivity，保存录音
        if (mListener != null) {
            mListener.onFinished(mTime, mAudioManager.getCurrentFilePath());
        }
        // 恢复标志位
        reset();
        //进度条计时取消
        countDownTimer.cancel();
        curPercentate = 0;
//        percentToAngle(curPercentate);
    }
}
