package com.voicemessage.myapplication.dao;

import android.content.Context;
import com.voicemessage.myapplication.bean.Record;
import com.voicemessage.myapplication.db.DBManager;
import java.util.List;

/**
 * 数据库操作类，增、删、改、查
 *
 * @author: wlp 2018年11月3 创建<br>
 */
public class RecordingDao {
    //db
    private DBManager mgr;
    public RecordingDao(Context context) {
        //初始化DBManager
        mgr = new DBManager(context);
    }

    public void add(Record record) {
        if (record == null) {
            return;
        }
        mgr.add(record);
    }

    public void updateRecord(Record record) {
        mgr.updateRecord(record);
    }

    public void deleteRecord(Record record) {
        mgr.deleteRecord(record);
    }

    /**
     * query all Records, return list
     * @return List<Record>
     */
    public List<Record> query() {
        return mgr.query();
    }

    /**
     * 清空一个数据库表内容
     */
    public void clearTable() {
        mgr.clearTable("Record");

    }
}
