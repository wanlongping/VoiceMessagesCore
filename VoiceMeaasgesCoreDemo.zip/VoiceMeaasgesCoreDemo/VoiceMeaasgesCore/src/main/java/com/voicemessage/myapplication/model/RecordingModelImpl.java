package com.voicemessage.myapplication.model;

import android.content.Context;

import com.voicemessage.myapplication.bean.Record;
import com.voicemessage.myapplication.dao.RecordingDao;
import com.voicemessage.myapplication.presenter.IRecordingPresenter;
import com.voicemessage.myapplication.utils.FileUtils;
import com.voicemessage.myapplication.utils.MD5Utils;

import static com.voicemessage.myapplication.view.RecordingMessagesAdapter.mRecords;

import java.util.ArrayList;

/**
 * MVP 的Model层接口实现类
 *
 * @author wlp 2018年11月15日 创建<br>
 */
public class RecordingModelImpl implements IRecordingModel{
    private static final String TAG = RecordingModelImpl.class.getSimpleName();
    private IRecordingPresenter mPresenter;
    //db操作
    public RecordingDao mgr;

    public RecordingModelImpl(Context context, IRecordingPresenter presenter) {
        this.mPresenter = presenter;
        //初始化RecordingDao
        mgr = new RecordingDao(context);
        mRecords = new ArrayList<Record>();
    }

    @Override
    public void addData(float seconds, String filePath) {
        //超过30条记录，则以最新的替换最旧的一条
        if(mRecords.size() >= 30) {
            String deleteFilePath = mRecords.get(0).getPath();
            mgr.deleteRecord(mRecords.get(0));
            mRecords.remove(0);
            //彻底删除单条音频文件，防止系统内存不足
            FileUtils.deleteFile(deleteFilePath);
        }

        Record recordModel = new Record();
        recordModel.setId(MD5Utils.getMd5(filePath));
        recordModel.setSecond((int) seconds <= 0 ? 1 : (int) seconds);
        recordModel.setPath(filePath);
        recordModel.setPlayed(false);
        //设置录音时间
        recordModel.setRecordTime(String.valueOf(System.currentTimeMillis()));
        mRecords.add(recordModel);
        //添加到数据库
        mgr.add(recordModel);
        mPresenter.addDataFinish();
    }
}
