package com.voicemessage.myapplication.bean;

/**
 * 核心录音信息字段Bean类
 *
 * @author wlp 2018年10月9日 创建<br>
 */
public class Record {
    //录音ID
    private String id;
    //录音存放路径
    private String path;
    //录音时长
    private int second;
    //是否已经播放过
    private boolean isPlayed;
    //是否正在播放
    private boolean isPlaying;
    //录音时间
    private String time;
    //是否显示录音当前时间
    private boolean isShowTime;

    /**
     * 录音ID
     * @return
     */
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 录音存放路径
     * @return
     */
    public String getPath() {
        return path;
    }
    public void setPath(String path) {
        this.path = path;
    }

    /**
     * 录音时长
     * @return
     */
    public int getSecond() {
        return second;
    }
    public void setSecond(int second) {
        this.second = second;
    }

    /**
     * 是否已经播放过
     * @return
     */
    public boolean isPlayed() {
        return isPlayed;
    }
    public void setPlayed(boolean played) {
        isPlayed = played;
    }

    /**
     * 是否正在播放
     * @return
     */
    public boolean isPlaying() {
        return isPlaying;
    }
    public void setPlaying(boolean playing) {
        isPlaying = playing;
    }

    /**
     * 录音时间
     * @return
     */
    public String getRecordTime() {
        return time;
    }
    public void setRecordTime(String time) {
        this.time = time;
    }

    /**
     * 是否显示录音当前时间
     * @return
     */
    public boolean isShowTime() {
        return isShowTime;
    }
    public void setShowTime(boolean showTime) {
        isShowTime = showTime;
    }

    @Override
    public String toString() {
        return "Record{" +
                "id='" + id + '\'' +
                ", path='" + path + '\'' +
                ", second=" + second +
                ", isPlayed=" + isPlayed +
                ", isPlaying=" + isPlaying +
                ", time=" + time +
                ", isShowTime=" + isShowTime +
                '}';
    }
}
