package com.voicemessage.myapplication.view;

/**
 * 录音留言中心视图接口
 *
 * @author wlp 2018年10月29日 创建<br>
 */
public interface IRecordingActivityView {
    void addDataFinish();
}
